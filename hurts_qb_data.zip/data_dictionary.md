# Hurts vs. Top QBs: Data Dictionary

Data pulled from **nflverse** (player stats, play-by-play, schedules, PFR advanced passing) on 2026-10-12.
Coverage: seasons **2018-2026**. **2026 is in progress** (through Week 5), so don't compare 2026 totals to full seasons; use rates.

## Files and how they relate (star schema for Power BI)

| File | Grain | Rows | Role |
|---|---|---|---|
| `fact_qb_season.csv` | one QB x season x season_type | 529 | Main fact. **All QBs with 50+ attempts** (so you can rank against the league), plus the 8 comparison QBs always. |
| `fact_qb_week.csv` | one QB x game | 771 | Game-by-game fact, **comparison group only** (8 QBs). |
| `dim_player.csv` | one QB | 132 | Names, headshots, group role, rookie year, color hex. |
| `dim_game.csv` | one game | 2,305 | Scores, spread, weather, starting QBs. |
| `dim_season.csv` | one season | 9 | Season label and in-progress flag. |

**Relationships:** `fact_qb_season.player_id` / `fact_qb_week.player_id` -> `dim_player.player_id`; `fact_qb_season.season` -> `dim_season.season`; `fact_qb_week.game_id` -> `dim_game.game_id`.

**Comparison group (8 QBs):** Jalen Hurts (Subject); Mahomes, Allen, Jackson, Burrow (Contemporary); Love, Stroud, Daniels (Rising). Flag: `in_comparison_group`.

## Conventions
- `season_type`: `REG` = regular season, `POST` = playoffs. **Filter to REG for most charts**, and use POST separately for the playoff question.
- All `*_rate`, `*_pct` and `success_rate` columns are **fractions (0-1)**. Format as % in the tool.
- `nfl_year` = season - rookie_season + 1, for aligning careers by experience (comparison group only). Mahomes' rookie year is 2017 but he only appears from 2018 (backup year not in data).
- Counting stats (yards, TDs, etc.) match official box scores. Spot-checked against known season lines for Hurts, Mahomes, Allen.

## fact_qb_season.csv (and fact_qb_week.csv where noted)

**Box score (both files):** `completions, attempts, passing_yards, passing_tds, passing_interceptions, sacks_suffered, sack_yards_lost, sack_fumbles, sack_fumbles_lost, passing_air_yards, passing_yards_after_catch, passing_first_downs, carries, rushing_yards, rushing_tds, rushing_fumbles_lost, rushing_first_downs, fantasy_points_ppr`
(the weekly file also has `fantasy_points`, and box-score `passing_epa` / `rushing_epa`).

**Derived (both files):** `completion_pct, yards_per_attempt, net_yards_per_attempt (sack-adjusted), pass_td_rate, int_rate, sack_rate (sacks / dropbacks), yards_per_carry, total_tds, total_yards, passer_rating` (computed with the NFL formula).
Season file only: `games_played, rush_yards_per_game, pass_yards_per_game`.

**Efficiency from play-by-play (both files):**
| Column | Definition |
|---|---|
| `pass_plays` | Dropbacks: pass attempts + sacks |
| `rush_plays` | QB runs, scrambles + designed. **Excludes kneels**, so it runs slightly below box-score `carries`. |
| `scrambles`, `designed_runs` | Split of `rush_plays` using nflverse's scramble flag |
| `total_plays` | `pass_plays + rush_plays` |
| `total_epa`, `pass_epa_total`, `rush_epa_total`, `scramble_epa_total`, `designed_run_epa_total` | Summed expected points added |
| `epa_per_play` | `total_epa / total_plays`. **The headline dual-threat efficiency number.** |
| `epa_per_pass_play`, `epa_per_rush` | Per-dropback and per-run EPA |
| `success_rate`, `pass_success_rate`, `rush_success_rate` | Share of plays with positive EPA |
| `cpoe` | Completion % over expected (mean over attempts) |
| `avg_air_yards` | Average depth of target |
| `clutch_plays`, `clutch_epa_per_play` | 4th quarter / OT plays with score within 8 points |

**Wins (season file only):** `starts, wins, losses, ties, win_pct`: team record in games where he was the **starting QB** (official starters from the schedule file). Blank if he had no starts.

**Pressure and context (season file only, regular season, from Pro Football Reference):** `pfr_pressure_rate, pfr_times_pressured, pfr_times_blitzed, pfr_times_hurried, pfr_times_hit, pfr_pocket_time_sec, pfr_bad_throw_rate, pfr_receiver_drop_rate, pfr_on_target_rate`. **Blank for 2026** (not published yet) and for POST rows.

**Flags (season file only):** `in_comparison_group, rookie_season, nfl_year, meets_150_attempts` (use as your "qualified QB" filter for league rankings), `season_complete`.

**Weekly-only game context:** `game_id, gameday, opponent, is_home, team_score, opp_score, team_result` (1 = win, 0.5 = tie, 0 = loss), `team_spread` (points the QB's team was favored by; negative = underdog), `team_rest` (days of rest), `started` (true if official starter).

## dim_player.csv
`player_id, player_name, headshot_url, latest_team, first_season_in_data, last_season_in_data, in_comparison_group, group_role, rookie_season, display_order, color_hex`
`color_hex` is a colorblind-friendly palette for the 8 QBs so Tableau and Power BI charts can match.

## dim_game.csv
`game_id, season, season_type, game_type (REG/WC/DIV/CON/SB), week, gameday, away_team, home_team, away_score, home_score, overtime, spread_line (positive = home favored), total_line, roof, surface, temp, wind, away_qb_id/name, home_qb_id/name`. Only played games.

## dim_season.csv
`season, reg_season_games_played, season_complete, season_label`

## Known limits (worth stating in your write-up)
- **No offensive-line or receiver-quality grades.** nflverse doesn't include pass-block win rate. `pfr_pressure_rate`, `pfr_pocket_time_sec` and `pfr_receiver_drop_rate` are the closest context proxies here.
- **Starts and wins are team results**, not QB-only credit.
- **Historical benchmarks (Brady, Manning) are not included.** Play-by-play with EPA goes back to 1999, so they can be added.
- **Ranks and percentiles are not pre-computed**, so you can practice building them (Tableau `RANK()` / table calcs, Power BI `RANKX`).
